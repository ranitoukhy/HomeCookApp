package il.co.appschool.homecook;

import android.support.annotation.NonNull;
import android.util.Log;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;

/**
 * @author : Rani Toukhy
 * This class represents a list of all of the ingredients that the app contains.
 */
public class IngredientList extends ArrayList<Ingredient>{

    private static final String TAG = "IngredientList";

    FirebaseFirestore db = FirebaseFirestore.getInstance();
    private static IngredientList ingredientList;

    /**
     *
     * @return : ingredientList
     * sharedInstance method- if the data had already been loaded, it wont load twice.
     */
    public static IngredientList sharedInstance() {
        if (ingredientList == null)
            ingredientList = new IngredientList();
        return ingredientList;
    }

    /**
     *
     * function that loads all of the ingredients.
     * @param : delegate
     * the delegate param connects between the classes IngredientList and MainActivity, to make sure the data loads successfully.
     * if the data loads successfully, the delegate param is true. else, its false.
     */
    public void loadIngredients(final DataLoaderDelegate delegate) {
        //final int length= this.size();
        db.collection("ingredients").orderBy("Category")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                Ingredient ingredient = new Ingredient();
                                int id=Integer.valueOf(document.get("IngredientID").toString());
                                ingredient.setId(id);
                                ingredient.setName(document.get("IngredientName").toString());
                                ingredient.setCategory(document.get("Category").toString());
                                add(ingredient);
                            }
                            delegate.dataLoadDidComplete(true);
                        } else {
                            Log.d(TAG, "Error getting documents: ", task.getException());
                            delegate.dataLoadDidComplete(false);
                        }
                    }
                });

    }

}

