package il.co.appschool.homecook;

import android.support.annotation.NonNull;
import android.util.Log;
import android.widget.ArrayAdapter;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;

/**
 * @author : Rani Toukhy.
 * This class represents a list of all of the recipes this app contains.
 */
public class RecipeList extends ArrayList<Recipe> {
    private static final String TAG = "RecipeList";
    FirebaseFirestore db = FirebaseFirestore.getInstance();
    private static RecipeList recipeList;
    IngredientList ingredientList = IngredientList.sharedInstance();

    public static RecipeList sharedInstance() {
        if (recipeList == null)
            recipeList = new RecipeList();
        return recipeList;
    }

    /**
     * function that loads all of the recipes.
     * @param : delegate
     * the delegate param connects between the classes RecipeList and MainActivity, to make sure the data loads successfully.
     * if the data loads successfully, the delegate param is true. else, its false.
     */
    public void loadRecipes(final DataLoaderDelegate delegate) {
        db.collection("recipes")//2
                .get()//3
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    //4
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                //5
                                Recipe recipe = new Recipe();
                                int id = Integer.valueOf(document.get("RecipeID").toString());
                                recipe.setName(document.get("RecipeName").toString());
                                recipe.setText(document.get("Instructions").toString());
                                recipe.setId(id);
                                recipe.setImageID(document.get("ImageID").toString());
                                add(recipe);
                            }

                            delegate.dataLoadDidComplete(true);
                        } else {
                            Log.d(TAG, "Error getting documents: ", task.getException());
                            delegate.dataLoadDidComplete(false);
                        }
                    }
                });

    }

    /**
     * function that loads all of the recipe's ingredients.
     * @param : delegate
     * the delegate param connects between the classes RecipeList and MainActivity, to make sure the data loads successfully.
     * if the data loads successfully, the delegate param is true. else, its false.
     */
    public void loadRecipeIngredients(final DataLoaderDelegate delegate) {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("recipeIngredients")//2
                .get()//3
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    //4
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {

                                Ingredient ing = new Ingredient();
                                int ingredientID = Integer.valueOf(document.get("IngredientID").toString());
                                ing.setId(ingredientID);
                                int index = Integer.valueOf(document.get("RecipeID").toString());
                                for (int i = 0; i < ingredientList.size(); i++) {
                                    if (ingredientList.get(i).getId() == ingredientID) {
                                        ing.setName(ingredientList.get(i).getName().toString());
                                        ing.setAmount(document.get("Amount").toString());
                                        for (int j = 0; j < size(); j++) {
                                            if (get(j).getId() == index) {
                                                if (index > 10)
                                                    get(j).getIngredients().add(ing);
                                                else
                                                    get(j).getIngredients().add(ing);
                                            }

                                        }

                                        break;
                                    }
                                }

                            }
                            delegate.dataLoadDidComplete(true);
                        } else {
                            Log.d(TAG, "Error getting documents: ", task.getException());
                            delegate.dataLoadDidComplete(false);
                        }
                    }
                });
    }

    /**
     *  function that loads all of the recipe's calories per 100g.
     * @param : delegate
     * the delegate param connects between the classes RecipeList and MainActivity, to make sure the data loads successfully.
     * if the data loads successfully, the delegate param is true. else, its false.
     */
    public void loadRecipeCalories(final DataLoaderDelegate delegate) {
        db.collection("recipeCalories")//2
                .get()//3
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    //4
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                //5
                                int index = Integer.valueOf(document.get("RecipeID").toString());
                                if (index > 10)
                                    get(index - 2).setCalories(Integer.valueOf(document.get("Calories").toString()));
                                else
                                    get(index - 1).setCalories(Integer.valueOf(document.get("Calories").toString()));
                            }
                            delegate.dataLoadDidComplete(true);
                        } else {
                            Log.d(TAG, "Error getting documents: ", task.getException());
                            delegate.dataLoadDidComplete(false);
                        }
                    }
                });

    }
}
