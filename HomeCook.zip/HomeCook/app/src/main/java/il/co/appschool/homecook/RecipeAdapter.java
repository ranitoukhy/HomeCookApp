package il.co.appschool.homecook;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.List;

/**
 * @author : Rani Toukhy.
 * This class's purpose is to adapt the content of a recipe on an item of the designed list.
 */
public class RecipeAdapter extends ArrayAdapter<Recipe> {
    Context context;
    List<Recipe> objects;
    int resource;
    public RecipeAdapter(Context context, int resource, int textViewResourceId, List<Recipe> objects) {
        super(context, resource, textViewResourceId, objects);

        this.context = context;
        this.objects = objects;
        this.resource= resource;
    }

    /**
     * This function gets the view of an item on the list, and adapts the content of the item to the designed list.
     * @param position
     * @param convertView
     * @param parent
     * These params are considered for the adaption of the content of the item.
     * @return view -> the view of th item
     */
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        LayoutInflater layoutInflater = ((Activity) context).getLayoutInflater();
        View view = layoutInflater.inflate(R.layout.custom_list_layout, parent, false);
        TextView tvName = (TextView) view.findViewById(R.id.tvName);
        TextView tvCalories = (TextView) view.findViewById(R.id.tvCalories);
        ImageView imageView = (ImageView) view.findViewById(R.id.ivImage);
        Recipe temp = objects.get(position);
        Picasso.get().load(temp.getImageID()).resize(50,50).centerCrop().into(imageView);
        tvName.setText(temp.getName());
        tvCalories.setText("("+String.valueOf(temp.getCalories())+ " Calories Per 100G"+")");
        TextView tvOut= view.findViewById(R.id.tvOut);
        if (resource==1)
        {
            tvOut.setText(String.valueOf(temp.getIngredients().size()-temp.getIngsFound())+"/"+temp.getIngredients().size()+" ingredients found");
            tvOut.setVisibility(View.VISIBLE);
        }
        else
            tvOut.setVisibility(View.GONE);


        return view;
    }
}