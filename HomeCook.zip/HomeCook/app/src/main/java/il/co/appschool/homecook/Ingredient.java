package il.co.appschool.homecook;

/**
 *
 * @author :  Rani Toukhy.
 * This class is a representation of a general recipe.
 */
public class Ingredient {
    private String name;
    private String amount;
    private int id;
    private String category;

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }



    public void setId(int id) {
        this.id = id;
    }

    public int getId() {

        return id;
    }

    public Ingredient(){}

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public void setName(String name) {

        this.name = name;
    }

    public String getAmount() {

        return amount;
    }

    public String getName() {
        return name;
    }



}
