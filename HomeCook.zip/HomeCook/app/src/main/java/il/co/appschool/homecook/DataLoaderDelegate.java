package il.co.appschool.homecook;

/**
 * @author : Rani Toukhy
 * This interface connects between MainActivity and the classes IngredientList and RecipeList, to let eachother know wether the data was successfully loaded, or wether it didn't.
 */
public interface DataLoaderDelegate {
    void dataLoadDidComplete(boolean isOk);
}
