package il.co.appschool.homecook;

import android.app.AlarmManager;
import android.app.Dialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.media.RingtoneManager;
import android.os.SystemClock;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.FirebaseApp;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/**
 * @author : Rani Toukhy.
 * @see MyReceiver
 * @see RecipeInfoActivity
 * @see RecipeAdapter
 * MainActivity is an activity that shows the user a list of all the recipes, their calory value, and a photo.
 */
public class MainActivity extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemClickListener {
    public static final String CHANNEL_ID = "channel01";
    IngredientList ingredientList = IngredientList.sharedInstance();
    ListView lv, lvIng;
    RecipeList recipeList = RecipeList.sharedInstance();
    ArrayAdapter<Recipe> recipeAdapter, foundAdapter;
    ArrayAdapter<Ingredient> ingredientAdapter;
    ArrayList<Ingredient> homeIngsList;
    ArrayList<Recipe> foundRecipesList;
    Button btnOriginal, btnFind, btnBack, btnSub, btnGot;
    Dialog d, about;
    FrameLayout flLoading;
    TextView tvTitle;

    /**
     * A function that mostly declares the id of widgets (such as buttons, linear layouts, etc') and calls other functions.
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        FirebaseApp.initializeApp(this);
        createChannel();
        scheduleNotification();
        loadIngredients();
        findDuplicates();
        lv = findViewById(R.id.lv);
        loadRecipes();
        lv.setOnItemClickListener(this);
        btnFind = findViewById(R.id.btnFind);
        btnOriginal = findViewById(R.id.btnOriginal);
        btnOriginal.setOnClickListener(this);
        btnFind.setOnClickListener(this);
        flLoading = findViewById(R.id.flLoading);
        foundRecipesList = new ArrayList<>();
        homeIngsList = new ArrayList<Ingredient>();
        tvTitle = findViewById(R.id.tvTitle);
    }

    /**
     * A function that loads all of the ingredients from the IngredientList class.
     * If the data doesn't load from any reason, the function calls the goTo function.
     */
    private void loadIngredients() {
        ingredientList.clear();
        ingredientList.loadIngredients(new DataLoaderDelegate() {
            @Override
            public void dataLoadDidComplete(boolean isOk) {
                if (!isOk) {
                    Log.d("IngredientList", "Error getting ingredients");
                    ingredientAdapter.notifyDataSetChanged();
                }
            }
        });
    }

    /**
     * A function that loads all of the recipes from the RecipeList class.
     * If the data doesn't load from any reason, the function calls the goTo function.
     */
    private void loadRecipes() {
        recipeList.clear();
        recipeAdapter = new RecipeAdapter(this, 0, 0, recipeList);
        lv.setAdapter(recipeAdapter);
        recipeList.loadRecipes(new DataLoaderDelegate() {
            @Override
            public void dataLoadDidComplete(boolean isOk) {
                if (isOk) {
                    MainActivity.this.recipeAdapter.notifyDataSetChanged();
                    loadRecipeCalories();
                } else {
                    Log.d("RecipeList", "Error getting recipes");
                    goTo();

                }
            }
        });
    }

    /**
     * A function that loads all of the recipes' ingredients from the RecipeList class.
     * If the data doesn't load from any reason, the function calls the goTo function.
     */
    private void loadRecipeIngredients() {
        recipeList.loadRecipeIngredients(new DataLoaderDelegate() {
            @Override
            public void dataLoadDidComplete(boolean isOk) {
                if (isOk) {
                    MainActivity.this.recipeAdapter.notifyDataSetChanged();
                    lv.setAdapter(recipeAdapter);
                    flLoading.setVisibility(View.GONE);
                } else {
                    Log.d("RecipeList", "Error getting recipe ingredients");
                    goTo();
                }
            }
        });
    }

    /**
     * A function that loads all of the recipes' calories per 100g from the RecipeList class.
     * If the data doesn't load from any reason, the function calls the goTo function.
     */
    private void loadRecipeCalories() {
        recipeList.loadRecipeCalories(new DataLoaderDelegate() {
            @Override
            public void dataLoadDidComplete(boolean isOk) {
                if (isOk) {

                    MainActivity.this.recipeAdapter.notifyDataSetChanged();
                    loadRecipeIngredients();
                } else {
                    Log.d("RecipeList", "Error getting recipe ingredients");
                    goTo();
                }
            }
        });
    }

    /**
     * A function that is only called when the recipe and ingredients data do not load.
     * A toast will be shown, letting the user know that the data did not load successfully.
     */
    public void goTo() {
        Toast.makeText(this, "Could Not Load Data", Toast.LENGTH_LONG).show();
        Intent intent2 = new Intent(this, MainActivity.class);
        startActivity(intent2);

    }

    /**
     * A function that shows the user the menu of the app.
     * @param menu -> the menu of the app.
     * @return a boolean param.
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.menu_about, menu);
        return true;
    }

    /**
     * The function handles what happens when the user clicks one of the menu items.
     * @param item -> an item that the menu contains.
     * @return a boolean param.
     */
    @Override

    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.itemAbout) {
            about = new Dialog(this);
            about.setContentView(R.layout.dialog_about);
            about.setTitle("Ingredients");
            about.setCancelable(true);
            btnGot = about.findViewById(R.id.btnGotIt);
            about.show();
            btnGot.setOnClickListener(this);
        }
        return true;
    }

    /**
     * A function that handles what happens when the user clicks on one of the list's items.
     * @param parent
     * @param view
     * @param position
     * @param id
     * All of these params are considered for what and when happens to which item on the list when it's clicked.
     */
    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Recipe recipe = (Recipe) lv.getAdapter().getItem(position);
        Intent intent = new Intent(MainActivity.this, RecipeInfoActivity.class);
        intent.putExtra("recipePosition", recipeList.indexOf(recipe));
        startActivityForResult(intent, 1);
    }

    /**
     * The function handles what happens when the user clicks on any one of the buttons that the app contains.
     * @param v -> button
     */
    @Override
    public void onClick(View v) {
        if (v == btnGot)
            about.dismiss();
        if (v == btnFind) {
            btnOriginal.setTextColor(Color.WHITE);
            btnFind.setTextColor(Color.BLACK);
            createIngredientsDialog();
        } else if (v == btnOriginal) {
            homeIngsList.clear();
            if (foundRecipesList.size() != 0)
                foundRecipesList.clear();
            recipeAdapter.notifyDataSetChanged();
            lv.setAdapter(recipeAdapter);
            btnOriginal.setTextColor(Color.BLACK);
            btnFind.setTextColor(Color.WHITE);
            tvTitle.setText("All Recipes");
        } else if (v == btnBack) {
            d.dismiss();
            homeIngsList.clear();
        } else if (v == btnSub) {
           findMatchedRecipes();
        }

    }

    /**
     * A function that creates the dialog that contains all of the ingredients, of which the user can choose to find matched recipes.
     */
    public void createIngredientsDialog() {
        d = new Dialog(this);
        d.setContentView(R.layout.dialog_ingredients);
        d.setTitle("Ingredients");
        d.setCancelable(false);
        homeIngsList = new ArrayList<>();
        d.show();
        btnSub = d.findViewById(R.id.btnSub);
        btnBack = d.findViewById(R.id.btnBack);
        btnBack.setOnClickListener(this);
        btnSub.setOnClickListener(this);
        final ListView lvIng = d.findViewById(R.id.lvIng);
        ingredientAdapter = new ArrayAdapter<Ingredient>(this, android.R.layout.activity_list_item, android.R.id.text1, ingredientList) {
            /**
             * A function that handles what happens when the user clicks on one of the list's items.
             * @param position
             * @param convertView
             * @param parent
             * @return a view.
             * All of these params are considered for how the list and it's items actually look like.
             */
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View view = super.getView(position, convertView, parent);
                Ingredient ingredient = (Ingredient) lvIng.getAdapter().getItem(position);
                TextView text = view.findViewById(android.R.id.text1);
                int iconResId = getResources().getIdentifier(ingredient.getCategory(), "drawable", getPackageName());
                ImageView icon = view.findViewById(android.R.id.icon);
                icon.setImageResource(iconResId);
                if (homeIngsList.contains(ingredient)) {
                    text.setTextColor(Color.RED);
                    text.setText(ingredient.getName());
                } else {
                    text.setTextColor(Color.BLACK);
                    text.setText(ingredient.getName());
                    icon.setImageResource(iconResId);
                }
                return view;

            }

        };
        lvIng.setAdapter(ingredientAdapter);
        MainActivity.this.ingredientAdapter.notifyDataSetChanged();
        lvIng.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            /**
             * A function that handles what happens when an item on the list is clicked.
             * @param parent
             * @param view
             * @param position
             * @param id
             *  All of these params are considered for what and when happens to which item on the list when it's clicked.
             */
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Ingredient ingredient = (Ingredient) lvIng.getAdapter().getItem(position);
                TextView textView = view.findViewById(android.R.id.text1);

                if (homeIngsList.contains(ingredient)) {
                    textView.setTextColor(Color.BLACK);
                    homeIngsList.remove(ingredient);
                } else {
                    textView.setTextColor(Color.RED);
                    homeIngsList.add(ingredient);
                }
            }
        });


    }

    /**
     * A function that finds, sorts and shows the user a list of all of the recipes that the user has half or more of the ingredients in those recipes.
     */
    public void findMatchedRecipes(){
        foundRecipesList = new ArrayList<>();
        for (int i = 0; i < recipeList.size(); i++) {
            int count = 0;
            for (int j = 0; j < recipeList.get(i).getIngredients().size(); j++) {

                for (int k = 0; k < homeIngsList.size(); k++) {
                    if (recipeList.get(i).getIngredients().get(j).getId() == homeIngsList.get(k).getId())
                        count++;
                }
            }
            if (count >= (recipeList.get(i).getIngredients().size()) / 2) {
                foundRecipesList.add(recipeList.get(i));
                recipeList.get(i).setIngsFound(recipeList.get(i).getIngredients().size()-count);
            }
        }
        if (homeIngsList.size() == 0)
            Toast.makeText(this, "Please Choose Ingredients", Toast.LENGTH_LONG).show();


        else {
            if (foundRecipesList.size() == 0)
                tvTitle.setText("No Results Found");
            else
                tvTitle.setText("Matched Recipes:");
            sortRecipes(foundRecipesList);
            foundAdapter = new RecipeAdapter(this, 1, 0, foundRecipesList);
            foundAdapter.notifyDataSetChanged();
            recipeAdapter.notifyDataSetChanged();
            d.dismiss();
            lv.setAdapter(foundAdapter);
        }
    }

    /**
     * This function sorts the recipes that have been found in the findMatchedRecipes function, by number of ingredients found out of the total number of ingredients in each recipe.
     * Meaning, the recipe that contains the most ingredients that the user has will be shown first and at the top of the list, and the recipe that contains the least ingredients that the user has will be shown last and at the bottom of the list.
     * @param list
     */
    public void sortRecipes(ArrayList<Recipe> list) {
        // ArrayList<Recipe> temp = new ArrayList<>();
        Collections.sort(list, new Comparator<Recipe>() {
            @Override
            public int compare(Recipe o1, Recipe o2) {
                return o1.getIngsFound() - o2.getIngsFound();
            }

        });

    }

    /**
     * This function creates a channel for the notification that the app makes.
     */
    private void createChannel() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            NotificationChannel chanel01 = new NotificationChannel(CHANNEL_ID, "chanel01", NotificationManager.IMPORTANCE_HIGH);
            notificationManager.createNotificationChannel(chanel01);
        }
    }

    /**
     * A function that schedules when the notification will appear.
     */
    public void scheduleNotification() {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID);
        builder.setContentTitle("HomeCook");
        builder.setContentText("Are you hungry? Explore new Recipes!");
        builder.setSmallIcon(R.drawable.foodicon);
        Notification notification = builder.build();
        delayNotification(notification, 10000);
    }

    /**
     * A function that uses the AlarmClock service, to delay the notification to the time it was scheduled, using the MyReceiver BroadcastReceiver.
     * @param notification
     * @param delay
     */
    private void delayNotification(Notification notification, int delay) {
        Intent notificationIntent = new Intent(this, MyReceiver.class);
        notificationIntent.putExtra(MyReceiver.NOTIFICATION_ID, 1);
        notificationIntent.putExtra(MyReceiver.NOTIFICATION, notification);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, 0, notificationIntent, 0);

        long futureInMillis = System.currentTimeMillis() + delay;
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        alarmManager.set(AlarmManager.RTC_WAKEUP, futureInMillis, pendingIntent);

    }
public void findDuplicates(){
        for (int i=0;i<recipeList.size();i++){
            if (recipeList.get(i).getCalories()==0)
                fixDuplicates();
        }
}
public void fixDuplicates(){
        for (int i=0;i<recipeList.size();i++){
            if (recipeList.get(i).getCalories()!=0)
                removeHalfIngredients(recipeList.get(i));
            else
                recipeList.remove(i);
        }
}
public void removeHalfIngredients(Recipe recipe){
        int temp =recipe.getIngredients().size()/2;
        for (int i=0;i<temp;i++){
            recipe.getIngredients().remove(i);
        }
}
}

