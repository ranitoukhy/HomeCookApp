package il.co.appschool.homecook;

import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

/**
 * @author : Rani Toukhy
 * This class shows the user all of the information of a recipe, when the user clicks on one of the items of the recipes list.
 */
public class RecipeInfoActivity extends AppCompatActivity implements View.OnClickListener {
Recipe recipe;
    LinearLayout lineDesc, lineSteps, lineNotes;
    Button btnDesc, btnSteps, btnNotes,  btnPlus, btnGot;
    EditText etComment;
    Dialog about;
    SharedPreferences sp;
    Animation animFadeIn;

    /**
     * A function that mostly declares the id of widgets (such as buttons, linear layouts, etc') and calls other functions.
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe_info);
        Intent intent = getIntent();
        recipe = RecipeList.sharedInstance().get(intent.getIntExtra("recipePosition", 0));

        TextView name = findViewById(R.id.tvName);
        name.setText(recipe.getName());
        ImageView imageView= findViewById(R.id.recipeImage);
        Picasso.get().load(recipe.getImageID()).into(imageView);
        TextView text = findViewById(R.id.tvInst);
        text.setText(recipe.getText());
        prepareIngredients();

            ImageView recipeImage = findViewById(R.id.recipeImage);
        Picasso.get().load(recipe.getImageID()).into(recipeImage);


        lineDesc= findViewById(R.id.lineDesc);
        lineNotes=findViewById(R.id.lineNotes);
        lineSteps=findViewById(R.id.lineSteps);
        btnDesc= findViewById(R.id.btnDesc);
        btnNotes=findViewById(R.id.btnNotes);
        btnSteps=findViewById(R.id.btnSteps);
        btnDesc.setOnClickListener(this);
        btnNotes.setOnClickListener(this);
        btnSteps.setOnClickListener(this);
        btnPlus= findViewById(R.id.btnPlus);
        btnPlus.setOnClickListener(this);
        etComment =  findViewById(R.id.etComment);
        animFadeIn= AnimationUtils.loadAnimation(this,R.anim.fade_in);
        sp=getSharedPreferences("recipeComment",0);
        String comment = sp.getString("mycomment"+ recipe.getName(),null);
        recipe.setComment(comment);
        if(comment!=null)
        {
            etComment.setText(recipe.getComment());
        }


    }

    /**
     * This function handles what happens when the user clicks on any one of the buttons that the app contains.
     * @param v  -> a button.
     */
    @Override
    public void onClick(View v) {
        if (v==btnDesc)
        {
            btnDesc.setTextColor(Color.BLACK);
            lineSteps.setVisibility(View.GONE);
            lineNotes.setVisibility(View.GONE);
            lineDesc.setVisibility(View.VISIBLE);
            btnSteps.setTextColor(Color.WHITE);
            btnNotes.setTextColor(Color.WHITE);
        }
        else if (v==btnSteps)
        {
            btnDesc.setTextColor(Color.WHITE);
            lineSteps.setVisibility(View.VISIBLE);
            lineNotes.setVisibility(View.GONE);
            lineDesc.setVisibility(View.GONE);
            btnSteps.setTextColor(Color.BLACK);
            btnNotes.setTextColor(Color.WHITE);
        }
        else if (v==btnNotes)
        {
            btnDesc.setTextColor(Color.WHITE);
            lineSteps.setVisibility(View.GONE);
            lineNotes.setVisibility(View.VISIBLE);
            lineDesc.setVisibility(View.GONE);
            btnSteps.setTextColor(Color.WHITE);
            btnNotes.setTextColor(Color.BLACK);
        }
        else if (v==btnPlus){
            btnPlus.startAnimation(animFadeIn);
            Toast.makeText(this,"Successfully Saved", Toast.LENGTH_LONG).show();
            recipe.setComment(etComment.getText().toString());
            SharedPreferences.Editor editor=sp.edit();
            editor.putString("mycomment"+recipe.getName(),recipe.getComment());
            editor.commit();
        }
        else if (v==btnGot)
            about.dismiss();

    }
    /**
     * A function that shows the user the menu of the app.
     * @param menu -> the menu of the app.
     * @return a boolean param.
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.menu_about, menu);
        return true;
    }

    /**
     * The function handles what happens when the user clicks one of the menu items.
     * @param item -> an item that the menu contains.
     * @return a boolean param.
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.itemAbout) {
            about = new Dialog(this);
            about.setContentView(R.layout.dialog_about);
            about.setTitle("Ingredients");
            about.setCancelable(true);
            btnGot = about.findViewById(R.id.btnGotIt);
            about.show();
            btnGot.setOnClickListener(this);
        }
        return true;
    }

    /**
     * A function that declares for each recipe which ingredients it contains, and the amount of each ingredient.
     */
    public void prepareIngredients(){
        String ings="";
        for (int i=0; i<recipe.getIngredients().size();i++){
            if (i==recipe.getIngredients().size()-1)
                ings+= recipe.getIngredients().get(i).getName()+"("+recipe.getIngredients().get(i).getAmount()+")";
            else
                ings+= recipe.getIngredients().get(i).getName()+"("+recipe.getIngredients().get(i).getAmount()+")"+","+ " ";
        }
        TextView ingredients= findViewById(R.id.tvIngs);
        ingredients.setText(ings);
    }
    }

