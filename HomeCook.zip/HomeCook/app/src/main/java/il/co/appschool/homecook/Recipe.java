package il.co.appschool.homecook;

import java.util.ArrayList;

/**
 * @author : Rani Toukhy.
 * This class is a representation of a general recipe.
 */
public class Recipe {
    private String name;
    private int calories;
    private ArrayList<Ingredient> ingredients;
    private String text;
    private int id;
    private String imageID;
    private String comment;
    private int ingsFound;

    public Recipe() {
    }
    public int getIngsFound() {
        return ingsFound;
    }

    public void setIngsFound(int ingsFound) {
        this.ingsFound = ingsFound;
    }





    public String getComment() {
        if (comment==null)
            comment="";
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }


    public void setImageID(String imageID) {
        this.imageID = imageID;
    }


    public String getImageID() {
        return imageID;
    }


    public void setId(int id) {
        this.id = id;
    }

    public int getId() {

        return id;
    }

    public void setText(String text) {
        this.text = text;
    }

    public void setIngredients(ArrayList<Ingredient> ingredients) {

        this.ingredients = ingredients;
    }

    public void setCalories(int calories) {

        this.calories = calories;
    }

    public String getText() {

        return text;
    }

    public ArrayList<Ingredient> getIngredients() {
        if (ingredients == null)
            ingredients = new ArrayList<>();
        return ingredients;
    }

    public int getCalories() {

        return calories;
    }

    public void setName(String name) {

        this.name = name;
    }

    public String getName() {

        return name;
    }

    public String toString(Recipe recipe) {
        String s = (recipe.getName() + " " + recipe.getCalories()).toString();
        return s;
    }

}
